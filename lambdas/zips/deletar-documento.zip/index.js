const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, DeleteCommand, QueryCommand } = require("@aws-sdk/lib-dynamodb");
const { S3Client, DeleteObjectCommand } = require("@aws-sdk/client-s3");

const client = new DynamoDBClient({ region: "sa-east-1" });
const dynamo = DynamoDBDocumentClient.from(client);
const s3 = new S3Client({ region: "sa-east-1" });

const BUCKET = "apsicare-documentos-23012668";
const TABLE_NAME = "PsicoCare";

exports.handler = async (event) => {
  const patientId = event.pathParameters?.patientId;
  const documentId = event.pathParameters?.documentId;

  if (!patientId || !documentId) {
    return resp(400, { error: "patientId e documentId são obrigatórios" });
  }

  try {
    // Busca o documento no DynamoDB para pegar o s3Key
    const result = await dynamo.send(new QueryCommand({
      TableName: TABLE_NAME,
      KeyConditionExpression: "PK = :pk AND begins_with(SK, :sk)",
      ExpressionAttributeValues: {
        ":pk": `PATIENT#${patientId}`,
        ":sk": `DOCUMENT#`,
      },
      FilterExpression: "contains(SK, :docId)",
      ExpressionAttributeValues: {
        ":pk": `PATIENT#${patientId}`,
        ":sk": `DOCUMENT#`,
        ":docId": documentId,
      }
    }));

    if (!result.Items || result.Items.length === 0) {
      return resp(404, { error: "Documento não encontrado" });
    }

    const doc = result.Items[0];

    // Deleta do S3
    if (doc.s3Key) {
      await s3.send(new DeleteObjectCommand({
        Bucket: BUCKET,
        Key: doc.s3Key,
      }));
    }

    // Deleta do DynamoDB
    await dynamo.send(new DeleteCommand({
      TableName: TABLE_NAME,
      Key: {
        PK: `PATIENT#${patientId}`,
        SK: doc.SK,
      }
    }));

    return resp(200, { message: "Documento deletado com sucesso" });

  } catch (err) {
    console.error(err);
    return resp(500, { error: "Erro ao deletar documento" });
  }
};

const resp = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  body: JSON.stringify(body)
});